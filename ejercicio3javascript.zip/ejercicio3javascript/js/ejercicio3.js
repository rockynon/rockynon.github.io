var nombre = prompt ('Cuál es tu nombre? :')
alert ('Hola! Bienvenid@ : ' + nombre + ', ingresa los números para ver el resultado de las diferenes operaciones matemáticas ')
var num1 = prompt ('Primer número: ');
var num2 = prompt ('Segundo número: ');
var sum =  num1 + num2;
var resta = num1 - num2;
var multip = num1 * num2;
var div = num1 / num2;

var peliculas = ['Forrest Gump ','Green Book ','Los Puentes de Madison ','Whiplash ','El Curioso Caso de Benjamin Button '];
peliculas.sort();

