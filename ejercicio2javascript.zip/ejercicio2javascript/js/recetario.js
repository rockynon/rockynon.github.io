var nombre = prompt ('Cuál es tu nombre? :')
alert ('Hola! Bienvenid@ : ' +nombre)
var ingrediente1 = prompt ('Ingresa el primer ingrediente:');
var ingrediente2 = prompt ('Ingresa el segundo ingrediente:');
var ingrediente3 = prompt ('Ingresa el último ingrediente:');
